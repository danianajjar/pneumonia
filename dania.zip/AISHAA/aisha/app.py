import os
import cv2
import numpy as np
from flask import Flask, render_template, request, redirect, url_for, flash, session, send_file
from flask_sqlalchemy import SQLAlchemy
from flask import make_response
from sqlalchemy.exc import IntegrityError
from flask_uploads import IMAGES, UploadSet, configure_uploads
from werkzeug.utils import secure_filename

from werkzeug.security import generate_password_hash, check_password_hash
app = Flask(__name__)
app.secret_key = 'your_secret_key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
app.config['UPLOADED_PHOTOS_DEST'] = r'C:/Users/aisha user\Desktop/rr'
photos = UploadSet('photos', IMAGES)
configure_uploads(app, photos)
db = SQLAlchemy(app)

app.app_context().push()

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String(80), nullable=False)
    last_name = db.Column(db.String(80), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    phone = db.Column(db.String(20), nullable=True)
    age = db.Column(db.Integer, nullable=True)
    password = db.Column(db.String(200), nullable=False)

# مجلد الصور الطبيعية
normal_images_folder = r'"E:/AISHAA (2)/chest_xray/chest_xray/test"'
# مجلد الصور المصابة
infected_images_folder =r'"E:/AISHAA (2)/chest_xray/chest_xray/train"'

# Function to compare the uploaded image with images in the specified folders
def compare_images(upload_path, normal_images_folder, infected_images_folder):
    # قراءة الصورة المحملة من المريض
    patient_image = cv2.imread(upload_path)
    patient_image = cv2.resize(patient_image, (224, 224))  # تحجيم الصورة إلى حجم معين

    # قائمة لحفظ الاختلافات بين الصور
    differences = []

    # تحقق من الصور في مجلد الصور الطبيعية
    for filename in os.listdir(normal_images_folder):
        if filename.endswith('.jpeg'):
            normal_image_path = os.path.join(normal_images_folder, filename)
            normal_image = cv2.imread(normal_image_path)
            normal_image = cv2.resize(normal_image, (224, 224))
            difference = np.mean(np.abs(patient_image - normal_image))
            differences.append((normal_image_path, difference))

   

# Route to handle image upload and comparison
@app.route('/compare', methods=['POST'])
def compare_uploaded_image():
    if 'photo' in request.files:
        photo = request.files['photo']
        if photo.filename != '':
            upload_path = os.path.join(app.config['UPLOADED_PHOTOS_DEST'], secure_filename(photo.filename))
            photo.save(upload_path)
            closest_image_path = compare_images(upload_path, normal_images_folder, infected_images_folder)
            if closest_image_path:
                return send_file(closest_image_path, mimetype='image/jpeg')
            else:
                return 'No closest image found.'
    return 'Image upload failed.'

# Function to check if an email exists in the database
def check_email_existence(email):
    user = User.query.filter_by(email=email).first()
    return user is not None

# Function to save user data to the database
def save_user_data(first_name, last_name, email, phone, age, password):
    hashed_password = generate_password_hash(password, method='sha256')
    new_user = User(first_name=first_name, last_name=last_name, email=email, phone=phone, age=age, password=hashed_password)
    db.session.add(new_user)
    db.session.commit()

# Function to authenticate a user
def authenticate_user(email, password):
    user = User.query.filter_by(email=email).first()
    if user and check_password_hash(user.password, password):
        return user
    else:
        return None

# Route for user login
@app.route('/login', methods=['POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        user = authenticate_user(email, password)
        if user:
            session['user_id'] = user.id
            session['user_email'] = user.email  # تخزين بيانات المستخدم في الجلسة
            flash('Login successful. Welcome back!', 'success')
        else:
            flash('Incorrect email or password. Please check your credentials.', 'error')

    return redirect(url_for('home'))

# داخل route الرئيسي
@app.route('/')
def home():
    user_email = request.cookies.get('user_email')  # احصل على قيمة البريد الإلكتروني من ملف تعريف الارتباط
    return render_template('app.html', user_email=user_email)



if __name__ == "__main__":
    app.run(debug=True,port=8000)